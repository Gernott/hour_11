<?php

return [
    'hour-plugin-hour' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:hour/Resources/Public/Icons/user_plugin_hour.svg'
    ],
];
